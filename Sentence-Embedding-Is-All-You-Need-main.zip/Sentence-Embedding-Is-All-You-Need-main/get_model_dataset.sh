#!/bin/bash
pip install gdown
gdown --folder https://drive.google.com/drive/folders/https://drive.google.com/drive/folders/140QpBbBPWXlqsbGZM1SpzhKDLMznq39B?usp=sharing -O Dataset
