#!/bin/bash
pip install gdown
gdown --folder https://drive.google.com/drive/folders/https://drive.google.com/drive/folders/1orQxudCmdOLvRUFJdWEEK31l7IOVUnWs?usp=sharing -O Checkpoint
